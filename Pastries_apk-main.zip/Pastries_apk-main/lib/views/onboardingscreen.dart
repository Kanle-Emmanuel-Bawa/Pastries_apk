import "package:flutter/material.dart";

// void main() {}

class OnboardingScreen extends StatelessWidget {
  const OnboardingScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        color: Colors.blueGrey,
        width: 400,
        height: 860,
        child: Stack(
          children: [
            SizedBox(
              width: double.infinity,
              height: 860,
              child: Image.asset(
                // 'asset/images/onboarding.jpg',
                'asset/images/onboard1.jpg',
                fit: BoxFit.cover,
              ),
            ),
            Positioned(
              bottom: 35,
              left: 10,
              right: 10,
              top: 430,
              child: Container(
                width: 350,
                height: 350,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.all(Radius.circular(35)),
                ),
                child: Stack(
                  children: [
                    Positioned(
                      top: 28,
                      left: 8,
                      right: 8,
                      child: Center(
                        child: Text(
                          'Fast Delivery At',
                          style: TextStyle(
                            fontSize: 25,
                            fontWeight: FontWeight(500),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      top: 62,
                      left: 10,
                      right: 10,
                      child: Center(
                        child: Text(
                          'Your Home',
                          style: TextStyle(
                            fontSize: 25,
                            fontWeight: FontWeight(500),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      top: 115,
                      left: 10,
                      right: 10,
                      // bottom: 35,
                      child: Center(
                        child: Text(
                          '''We have the best chips you can never  \n miss for all your order we got you ''',
                          style: TextStyle(
                            fontSize: 15,
                            fontWeight: FontWeight(150),
                          ),
                        ),
                      ),
                    ),

                    Positioned(
                      top: 130,
                      left: 10,
                      right: 10,
                      bottom: 0,
                      child: Center(
                        child: SizedBox(
                          width: 290,
                          child: ElevatedButton(
                            onPressed: () {},
                            // borderRadius:BorderRadius.all(Radius.circular(23)),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.orange,
                            ),
                            child: Text(
                              'Get Started',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 15,
                                fontWeight: FontWeight(280),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// class MyWidget extends StatelessWidget {
//   const MyWidget({super.key});

//   @override
//   Widget build(BuildContext context) {
//     return const Placeholder();
//   }
// }
